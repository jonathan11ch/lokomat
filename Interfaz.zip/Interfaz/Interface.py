import PyQt5
from PyQt5 import QtWidgets,QtGui
import sys
import sys
from PyQt5.QtCore import QSize
from PyQt5.QtGui import QImage, QPalette, QBrush
from PyQt5.QtWidgets import *

class Window(QtWidgets.QWidget):
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        
    def init_ui(self):
        
        self.setWindowTitle("Lokomat therapy")
        self.setGeometry(100,100,1000,600)#Tamaño de la ventana 
        Image=QImage("back1.jpg")
        sImage=Image.scaled(QSize(1000,600))
        palette=QPalette()
        palette.setBrush(10, QBrush(sImage))
        self.setPalette(palette)
        self.label1=QtWidgets.QLabel(self)
        self.label1.setText("Heart Rate")
        self.label1.setStyleSheet("font-size:20px; Arial")
        self.label1.setGeometry(40,40, 100,100)
        self.label2=QtWidgets.QLabel(self)
        self.label2.setText("Yaw")
        self.label2.setStyleSheet("font-size:20px; Arial")
        self.label2.setGeometry(50,110, 100,100)
        self.label3=QtWidgets.QLabel(self)
        self.label3.setText("Pitch")
        self.label3.setStyleSheet("font-size:20px; Arial")
        self.label3.setGeometry(50,180, 100,100)
        self.label4=QtWidgets.QLabel(self)
        self.label4.setText("Roll")
        self.label4.setStyleSheet("font-size:20px; Arial")
        self.label4.setGeometry(50,250, 100,100)
        self.textbox=QtWidgets.QLineEdit(self)
        self.textbox.setGeometry(150,65, 100,50)
        self.textbox.setStyleSheet("font-size:20px; Arial")
        self.textbox1=QtWidgets.QLineEdit(self)
        self.textbox1.setGeometry(150,130, 100,50)
        self.textbox1.setStyleSheet("font-size:20px; Arial")
        self.textbox1=QtWidgets.QLineEdit(self)
        self.textbox1.setGeometry(150,130, 100,50)
        self.textbox1.setStyleSheet("font-size:20px; Arial")
        self.textbox2=QtWidgets.QLineEdit(self)
        self.textbox2.setGeometry(150,200, 100,50)
        self.textbox2.setStyleSheet("font-size:20px; Arial")
        self.textbox3=QtWidgets.QLineEdit(self)
        self.textbox3.setGeometry(150,270, 100,50)
        self.textbox3.setStyleSheet("font-size:20px; Arial")
        self.label11=QtWidgets.QLabel(self)
        self.label11.setText("Bpm")
        self.label11.setStyleSheet("font-size:20px; Arial")
        self.label11.setGeometry(280,40, 100,100)
        self.label21=QtWidgets.QLabel(self)
        self.label21.setText("°")
        self.label21.setStyleSheet("font-size:20px; Arial")
        self.label21.setGeometry(280,110, 100,100)
        self.label31=QtWidgets.QLabel(self)
        self.label31.setText("°")
        self.label31.setStyleSheet("font-size:20px; Arial")
        self.label31.setGeometry(280,180, 100,100)
        self.label41=QtWidgets.QLabel(self)
        self.label41.setText("°")
        self.label41.setStyleSheet("font-size:20px; Arial")
        self.label41.setGeometry(280,250, 100,100)
        self.Start=QtWidgets.QPushButton(self)
        self.Start.setText("Start")
        self.Start.setGeometry(50,400,100,80)
        self.Start.setStyleSheet("font-size:20px; Arial")
        self.Start.setIcon(QtGui.QIcon('play2'))
        self.Start.setIconSize(QSize(40,40))
        self.Stop=QtWidgets.QPushButton(self)
        self.Stop.setText("Stop")
        self.Stop.setGeometry(160,400,100,80)
        self.Stop.setStyleSheet("font-size:20px; Arial")
        self.Stop.setIcon(QtGui.QIcon('stop'))
        self.Stop.setIconSize(QSize(40,40))
        self.LabelPosture=QtWidgets.QLabel(self)
        self.LabelPosture.setGeometry(760,60,220,440)
        self.LabelPosture.setPixmap(QtGui.QPixmap('cervical'))
        self.LabelTitle=QtWidgets.QLabel(self)
        self.LabelTitle.setGeometry(788,10,240,30)
        self.LabelTitle.setText("Posture Behavior")
        self.LabelTitle.setStyleSheet("font-size:20px ;Arial")
        #self.Stop.setIconSize(QSize(800,500))
        self.LabelPosture1=QtWidgets.QLabel(self)
        self.LabelPosture1.setGeometry(340,100,400,300)
        self.LabelPosture1.setPixmap(QtGui.QPixmap('cervical'))
        
        
        
        

        

        
        
        
        

        #self.Label1=QtWidgets.QLabel(self)
        #self.Label1.setText("Hello World")
        #self.Label2=QtWidgets.QLabel(self)
        #self.Label2.setPixmap(QtGui.QPixmap('Imagen'))
        #self.btn=QtWidgets.QPushButton(self)
        #self.btn.setText("Start")
        #self.btn.move(100,50)

        #self.Label1.move(130,20)#mover el label
        #self.Label2.move(120,90)
        self.show()
        

app=QtWidgets.QApplication(sys.argv)
GUI=Window()
sys.exit(app.exec_())

#M=run()

        
    
